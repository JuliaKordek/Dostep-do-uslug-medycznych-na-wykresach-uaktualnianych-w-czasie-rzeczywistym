import pandas as pd
import random
from faker import Faker

fake = Faker('PL_pl')

streets = ['ul. Długa', 'ul. Kartuska', 'ul. Świętojańska', 'ul. Mariacka', 'ul. Wały Jagiellońskie', 'ul. Podwale Staromiejskie']

def generate_patient_data(num):
    patient_list = []
    for p in range(1, num):
        patient = {}
        patient['first_name'] = fake.first_name()
        patient['last_name'] = fake.last_name()
        patient['pesel'] = fake.random_number(digits=11)
        patient['address'] = f"Gdańsk, {random.choice(streets)} " + str(random.randint(1,150))
        patient['phone_number'] = fake.phone_number()
        patient['email'] = fake.email()
        patient['disease'] = fake.random_element(elements=('grypa', 'zapalenie płuc', 'astma', 'nadciśnienie', 'cukrzyca', 'choroba serca', 'reumatyzm', 'nowotwór'))
        patient['place'] = fake.random_element(elements=('Centrum Medyczne', 'Medovec', 'Poradania rodzinna', 'NZOZ Glińskiego', 'Miła Przychodnia', 'OpoMed'))
        patient_list.append(patient)
    return pd.DataFrame(patient_list)

data = generate_patient_data(2000)
data.to_csv('med_data.csv')

